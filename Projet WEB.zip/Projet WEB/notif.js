let popup = document.getElementById("#popup");


console.log(popup);

function openPopup() {
    popup.classList.add(".open-popup");
}

function closePopup() { // Ajout de la fonction closePopup()
    popup.classList.remove(".open-popup");
}



